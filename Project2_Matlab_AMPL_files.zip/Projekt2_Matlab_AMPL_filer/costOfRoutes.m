function [totCost] = costOfRoutes(ProblemSize,ROUTE)
numStop = 0; 
distc2c = 0;
distd2c = 0; 

for n = ROUTE
    from = 2;
    len = length(n{1});
    numStop = numStop + len-1;
    distd2c = distd2c + ProblemSize.Dist.d2c(abs(n{1}(1)),n{1}(2))+ProblemSize.Dist.d2c(abs(n{1}(1)),n{1}(len));
    if len > 2
        while from < len
        to = from + 1;
        distc2c = distc2c + ProblemSize.Dist.c2c(n{1}(from),n{1}(to));
        from = from + 1;
        end
    end
end

distc2cCost = distc2c*12;
distd2cCost = distd2c*12;
routeFixedCost = length(ROUTE)*300;
stopCost = numStop*40;
totCost = distc2cCost+distd2cCost+routeFixedCost+stopCost;
end

