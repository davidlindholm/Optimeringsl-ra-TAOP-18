% This function add customers to a route until capacity is full.
% If capacity is full, it add customers to next route.
function [newRoute] = createNewRoute(ProblemSize,depot,customerCell)

tour = [-depot];
capacityLeft = ProblemSize.Capacity;
newRoute = {};
iter = 0; 

for index = 1:length(customerCell{depot})
    currentCustomer = customerCell{depot}(index);   
    
    % If we have capacity to add currentCustomer
    if capacityLeft >= ProblemSize.Demand(currentCustomer) 
        tour = [tour currentCustomer];
        capacityLeft = capacityLeft - ProblemSize.Demand(currentCustomer);
        
        % If we are in last iteration. Add the created tour
        if index == length(customerCell{depot}) 
            iter = iter + 1; 
            newRoute{iter} = tour;
            tour = [-depot];
            capacityLeft = ProblemSize.Capacity;
            
        else 
            nextCustomer = customerCell{depot}(index + 1);
     
            % If we dont have capacity to add nextCustomer
            % Add created tour and reset tour and capacity.
            if capacityLeft - ProblemSize.Demand(nextCustomer) < 0
                iter = iter + 1; 
                newRoute{iter} = tour;
                capacityLeft = ProblemSize.Capacity;
                tour = [-depot];
            end
        end       
        
    else  % If we dont have capacity to add current customer in tour.
        tour = [-depot currentCustomer];
        capacityLeft = ProblemSize.Capacity - ProblemSize.Demand(currentCustomer);
        
        if index == length(customerCell{depot}) % If we are in last iteration. Add the created tour
            iter = iter + 1; 
            newRoute{iter} = tour;
            tour = [-depot];
            capacityLeft = ProblemSize.Capacity;
        else 
            nextCustomer = customerCell{depot}(index + 1);
     
            % If we dont have capacity to add nextCustomer
            % Add created tour and reset tour and capacity.
            if capacityLeft - ProblemSize.Demand(nextCustomer) < 0
                iter = iter + 1; 
                newRoute{iter} = tour;
                capacityLeft = ProblemSize.Capacity;
                tour = [-depot];
            end
        end
    end 
end
end

