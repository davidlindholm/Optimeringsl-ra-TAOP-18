%%%%%% Assignment 3.

load('LARGE');load('MEDIUM');load('SMALL');
ProblemSize = LARGE; 

%% A1 - Assign customers to the depots 
customerDepot = assignCustomer(ProblemSize);
%plotDepotAssignment(ProblemSize,customerDepot(:,2),0,[1:ProblemSize.nrDepots])

%% A2 - find a feasible solution
ROUTE = findFirstRoute(ProblemSize);
%plotSolution(ProblemSize,ROUTE,1)

%% Calculate cost of routes.
costOfRoutes(ProblemSize,ROUTE)

% Tabu
close all;
clc;
customerCell = createCustomerCell(ProblemSize, ROUTE);

bestSol = inf; % UBD
localSol = inf;
solRoute = {}; % Here are the new ROUTE stored.
maxIterationsPerDepot = 1000;
oldSolutions = zeros(ProblemSize.nrDepots, maxIterationsPerDepot); % Keeps old solution to be used in plotProgress
tabuLength = 10; 
tabuList = zeros(1,tabuLength);

for depot = 1:ProblemSize.nrDepots % Loop through all depots
    
    bestSol = inf;
    orginalDepot = customerCell{depot};
    customerVector = customerCell{depot};
    solRouteIndex = length(solRoute);
    
    tabu = 0;
    tabuList = zeros(1,tabuLength);
    
    % Iterating over one VRP problem at a depot
    for iteration = 1:maxIterationsPerDepot
        
        localSol = inf;

        for i = 1:length(customerCell{depot});
            
            % Switch order of two adjecent customers.
            if ~any(i == tabuList)
                if i == length(customerCell{depot})
                    customerVector([i,1]) = customerVector([1,i]);
                    customerCell{depot} = customerVector;
                else
                    customerVector([i,i+1]) = customerVector([i+1,i]);
                    customerCell{depot} = customerVector;
                end
            
                % Add the customers to a route and calculate cost
                newRoute = createNewRoute(ProblemSize,depot,customerCell);
                currentCost = costOfRoutes(ProblemSize,newRoute);

                if currentCost < bestSol % Best (global) found solution
                    bestSol = currentCost;
                    bestRoute = newRoute;
                end

                if currentCost < localSol % Best (local) found solution
                    localSol = currentCost;
                    customerSwap = i;
                    bestCustomerVector = customerVector;
                end
            end
            
        end
        
        customerCell{depot} = bestCustomerVector;
        tabu = customerSwap;
        
        for n = tabuLength:-1:2
            tabuList(n) = tabuList(n-1);
        end
        tabuList(1) = tabu; 

        
        oldSolutions(depot, iteration) = localSol;
 
    end
    
    for bestRouteIndex = 1:length(bestRoute) % Add bestRoute to our new ROUTE (solROUTE)
        solRouteIndex = solRouteIndex + 1;
        solRoute{solRouteIndex} = bestRoute{bestRouteIndex};
    end
    
end

for depot = 1:ProblemSize.nrDepots
    plotProgress(oldSolutions(depot,:),1);
end

plotSolution(ProblemSize,solRoute,2)
costFromA2 = costOfRoutes(ProblemSize,ROUTE)
bestCurrentCost = costOfRoutes(ProblemSize,solRoute)
