load('LARGE');load('MEDIUM');load('SMALL');
ProblemSize = LARGE; 

%% A1 - Assign customers to the depots 
customerDepot = assignCustomer(ProblemSize);
%plotDepotAssignment(ProblemSize,customerDepot(:,2),0,[1:ProblemSize.nrDepots])

%% A2 - find a feasible solution
ROUTE = findFirstRoute(ProblemSize);
%plotSolution(ProblemSize,ROUTE,1)

%% Calculate cost of routes.
costOfRoutes(ProblemSize,ROUTE)


