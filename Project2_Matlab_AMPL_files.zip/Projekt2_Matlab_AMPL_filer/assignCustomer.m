function [customerDepot] = assignCustomer(ProblemSize)
%ProblemSize = SMALL; %SMALL or MEDIUM or LARGE
currentLoad = [[linspace(0,0,ProblemSize.nrDepots)]']; % Capacity left for the depots
customerDepot = [[1:ProblemSize.nrCustomers]' [linspace(0,0,ProblemSize.nrCustomers)]']; % Shows which customer that belong to a depot
customerLeft = [[ProblemSize.Dist.d2c] ;[1:ProblemSize.nrCustomers]]; % Shows the customers that are left to be assigned to a depot
[R K] = size(customerLeft);

while length(customerLeft) > 0
    for depot = 1:ProblemSize.nrDepots;
        [dist, index] = min(customerLeft(depot,:));
        if ProblemSize.Demand(customerLeft(R,index)) + currentLoad(depot) <= ProblemSize.Supply(depot);
            customerDepot(customerLeft(R,index),2) = depot;
            currentLoad(depot) = ProblemSize.Demand(customerLeft(R,index)) + currentLoad(depot);
            customerLeft(:,index) = [];
        end
    end
end
end