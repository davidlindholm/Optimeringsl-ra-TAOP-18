% This function puts all the customers in a "customerCell"
% a cell in "customerCell" contains all customers added to a depot in
% order.
function [customerCell] = createCustomerCell(ProblemSize, ROUTE)
customerCell = {};
for depot = 1:ProblemSize.nrDepots
customerList = [];
for n = ROUTE
    len = length(n{1});
    if abs(n{1}(1)) == depot 
    customerList = [customerList n{1}([2:len])];
    end
end
customerList;
customerCell{depot} = customerList;
end
end