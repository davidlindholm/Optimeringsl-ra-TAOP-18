function [ROUTE] = findFirstRoute(ProblemSize)
i = 1;
ROUTE = {};
%customerDepot = assignCustomer(ProblemSize); % Heuristic sol from A1
customerDepot = load('customerDepot.mat');   % Opt sol from AMPL
customerDepot = customerDepot.customerDepot; % Opt sol from AMPL
for depot = 1:ProblemSize.nrDepots
    distc2d = [[ProblemSize.Dist.d2c(depot,:)];[1:ProblemSize.nrCustomers]];
    distc2c = [ProblemSize.Dist.c2c;[1:ProblemSize.nrCustomers]];
    [R K] = size(distc2c);
    assignedCustomers = find(customerDepot(:,2) == depot);
    % V?lj f?rsta kund
    while isempty(assignedCustomers) == 0
        printCustomers = [];
        distLeft = distc2d(:,[assignedCustomers]);
        [dist, index] = min(distLeft(1,:));
        customerChoose = distLeft(2,index);
        helpCustomer = customerChoose;
        currentLoad = ProblemSize.Demand(customerChoose);
        
        % V?lj rutt
        while ProblemSize.Capacity > currentLoad
            distLeft = distc2c([customerChoose R],[assignedCustomers]);
            [dist, index] = min(distLeft(1,:));
            customerChoose = distLeft(2,index);
            if ProblemSize.Demand(customerChoose) + currentLoad > ProblemSize.Capacity
                break
            end
            currentLoad = ProblemSize.Demand(customerChoose) + currentLoad;
            printCustomers = [printCustomers customerChoose];
            assignedCustomers(find(assignedCustomers == customerChoose)) = [];
        end
        
        if helpCustomer == customerChoose
            ROUTE(i) = {[-depot helpCustomer]};
            assignedCustomers(find(assignedCustomers == customerChoose)) = [];
        else
            ROUTE(i) = {[-depot printCustomers]};
        end
        i = i + 1;
    end
end
end

